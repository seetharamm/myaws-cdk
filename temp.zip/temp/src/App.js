import React from "react";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./common/header/Header";
import Home from "./home/Home";
import ResidualValues from "./residualvalues/ResidualValues";
//import Fees from "./fees/Fees";
import Trim from "./trim/Trim";
import Job from "./jobs/Job";
import "./App.css";
import Year from "./Year";
import MoneyFactor from "./Money factor/MoneyFactor";
import APR from "./APR/APR";
import Tabpanel from "./common/Tabpanel";

// import RouteGuard from './components/routeGuard';

const theme = createTheme({
  palette: {
    mode: "light",
    primary: {
      main: "#8A6E33",
    },
    secondary: {
      main: "#e4dfd4",
    },
    background: {
      default: "#F1F1F1",
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <Router>
        <div>
          <Header />
          <Routes>
            <Route path="/" exact element={<Tabpanel />} />
            {/* <RouteGuard exact path ="/" element={<Home/>}/> */}
            <Route path="/trim" element={<Trim />} />
            <Route path="/model" element={<Job />} />
            <Route path="/residualvalues" element={<ResidualValues />} />
            <Route path="/year" element={<Year />} />
            <Route path="/money-factor" element={<MoneyFactor />} />
            <Route path="/APR" element={<APR />} />
            {/* Add more routes here */}
          </Routes>
        </div>
      </Router>
    </ThemeProvider>
  );
}

export default App;
