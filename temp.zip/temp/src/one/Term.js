import React, { useState } from "react";
import Select from "react-select";
import makeAnimated from "react-select/animated";
import { get } from "../common/api.js";
import { Grid, Typography } from "@mui/material";
import { Button, Modal, Box, TextField, Stack } from "@mui/material";
import { Add, Edit, Delete, ImportExport } from "@mui/icons-material";
import ImportCSV from "../common/excel/ImportCSV";

const Term = () => {
  const years = get("/apiForTerm");
  const animatedComponents = makeAnimated();
  return (
    <div>
      <Typography variant="h6" component="h1" sx={{ m: 0.5 }}>
        Term
      </Typography>
      <Typography variant="body1">
        <Select
          name="Term"
          closeMenuOnSelect={false}
          components={animatedComponents}
          //   defaultValue={years[([4], years[5])]}
          isMulti
          options={years}
        />
      </Typography>
    </div>
  );
};

export default Term;
