import { React, useState, useEffect, useRef } from "react";
import { Grid, Typography } from "@mui/material";
import { get, post, put, deleteRecord, handleApiError } from "../common/api";
import { DataGrid } from "@mui/x-data-grid";
import "../App.css";

import { CircularProgress, Button, Modal, Box, TextField, Stack, Dialog, DialogActions, DialogContent, DialogTitle } from "@mui/material";
import { Add, Edit, Delete, ImportExport } from "@mui/icons-material";
import Papa from "papaparse";
import { useCSVReader } from "react-papaparse";
import TableForCSVImport from "./import";
import Form from '@rjsf/mui';
import validator from '@rjsf/validator-ajv8';
import Snackbar, { SnackbarOrigin } from '@mui/material/Snackbar';

const ResidualValues = () => {
  const [rows, setRows] = useState([]);
  const [selectedRow, setSelectedRow] = useState(null);
  const [open, setOpen] = useState(false);

  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState();
  const [showStatus, setShowStatus] = useState(false);

  const [schema, setSchema] = useState({});

  const [openImport, setOpenImport] = useState(false);
  const [openTable, setOpenTable] = useState(false);
  const [dataFromCSV, setDataFromCSV] = useState([]);
  const [input, setInput] = useState({
    Edition: "",
    ModelYear: "",
    Make: "",
    Model: "",
    Trim: "",
    Miles: "",
    MSRP: "",
    MRM: "",
    Term: "",
    RV: "",
  });

  const [openCSV, setOpenCSV] = useState(false);
  const [importCSVData, setImportCSVData] = useState(false);
  const [file, setFile] = useState(null);

  const handleFileUpload = (event) => {
    const uploadedFile = event.target.files[0];
    setFile(uploadedFile);
  };

  const handleCloseCSV = () => {
    setOpenCSV(false);
  };

  // const handleSave = () => {
  //   handleCloseCSV();
  // };

  const arr = [];
  const handleChangeCSV = (event) => {
    // const file = event.target.files[0];
    Papa.parse(file, {
      header: true,
      // delimiter: ",",
      complete: (results) => {
        console.log("Data from Excel", results.data);

        // const arr = [...results.data];
        // arr.push(results.data);
        // results.data.map((item) => {
        //   arr.push[
        //     {
        //       Edition: item.Edition,
        //       ModelYear: item.ModelYear,
        //       Make: item.Make,
        //       Model: "",
        //       Trim: "",
        //       Miles: "",
        //       MSRP: "",
        //       MRM: "",
        //       Term: "",
        //       RV: "",
        //     }
        //   ];
        // });
        dataFromCSV.push(results.data);
        console.log("Data fetching attempt", dataFromCSV);
        setTimeout(() => {
          setDataFromCSV((old) => [...old, arr]);
          // setDataFromCSV(arr);
        }, 500);
        console.log("Parsing attempt", dataFromCSV);
        // Using the parsed data to display
        // const { id, values } = results.data;
        // setDataFromCSV(JSON.stringify([...results.data]));
        // setDataFromCSV(arr);
        // setDataFromCSV((pre) => [...pre, values[id]]);
        // post("",results.data); Send values to server via api
      },
    });
    setOpenTable(true);
    handleCloseCSV();
    setImportCSVData(true);
    // setValue(event.target.value);
  };





  const uiSchema = {
    "ui:ObjectFieldTemplate": ObjectFieldTemplate,
  };


  const fetchData = async () => {
    const response = await get("/residualvalues");
    if (response && response.length > 0) setRows(response);
  };
  const getModel = async () => {
    let models = [];
    const response = await get("/vehiclemodel");
    if (response && response.length > 0) {
      models = response;
    }
    return models;

  };

  const getTrim = async () => {
    let trims = [];
    const response = await get("/trim");
    if (response && response.length > 0) {
      trims = response;
    }
    return trims;
  };

  const getYear = () => {
    let year = [];
    const currentYear = (new Date()).getFullYear();
    const range = (start, stop, step) => Array.from({ length: (stop - start) / step + 1 }, (_, i) => start + (i * step));
    year = (range(currentYear, currentYear - 20, -1));
    return year;
  };

  useEffect(() => {
    fetchData();

    async function loadLookups() {
      const models = await getModel();
      const trims = await getTrim();
      const years = getYear();

      prepareForm(models, trims, years);
    }
    loadLookups();

  }, []);

  const prepareForm = (models, trims, years) => {

    let schemaWithLookups = {
      type: 'object',
      required: [
        "Edition",
        "Model",
        "Miles",
        "Trim",
        "Term",
        "RV"
      ],
      properties: {
        Edition: {
          type: 'string',
          title: 'Edition',
        },
        ModelYear: {
          type: 'number',
          title: 'Year',
          enum: years
        },
        Make: {
          type: 'string',
          title: 'Make',
          default: 'Lucid',
        },
        Model: {
          type: 'string',
          title: 'Model',
          enum: models.map(x => x.name),
          default: "Lucid Air"
        },
        Trim: {
          type: 'string',
          title: 'Trim',
          enum: trims.map(x => x.name),
        },
        Miles: {
          type: 'number',
          title: 'Miles'
        },
        MSRP: {
          type: 'number',
          title: 'MSRP'
        },
        MRM: {
          type: 'number',
          title: 'MRM'
        },
        Term: {
          type: 'number',
          title: 'Term',
          enum: [24, 36, 48, 60, 72]
        },
        RV: {
          type: 'number',
          title: 'Residual Values'
        },
      },
      dependencies: {
        Model: {
          oneOf: [
          ]
        }
      }
    };

    trims.forEach((x) => {
      let dependency = {
        properties: {
          Model: {
            enum: [x.model]
          },
          Trim: {
            type: "string",
            title: "Trim",
            enum: trims.filter((y) => y.model == x.model).map((z) => z.name)
          }
        }
      }
      schemaWithLookups.dependencies.Model.oneOf.push(dependency)
    })

    setSchema(schemaWithLookups);
  }
  const handleClose = () => {
    setOpen(false);
  };
  const handleAddValue = () => {
    setSelectedRow(null);
    setOpen(true);
  }
  const handleEditValue = () => {
    setOpen(true);
  }
  const log = (type) => console.log.bind(console, type);

  function handleChange(e) {
    const { name, value } = e.target;
    setInput((prevInput) => ({ ...prevInput, [name]: value }));
  }

  const handleSave = async (data) => {
    setLoading(true);

    let response;

    if (data._id)
      response = await put("/residualvalues/" + data._id, data);
    else
      response = await post("/residualvalues", data);

    if (response) {
      setSelectedRow(null);
      setOpen(false);
      setStatus("Residual value saved successfully.")
      setShowStatus(true);

      fetchData();

    }
    else {
      setStatus("Error occured while adding the residual value.")
      setShowStatus(true);
    }
    setLoading(false);
  };
  const handleDeleteValue= async () => {
    setLoading(true);

    if (selectedRow._id) {
      const response = await deleteRecord("/residualvalues/" + selectedRow._id);
      setLoading(false);
      fetchData();
      setStatus("Residual value deleted successfully.")
      setShowStatus(true);
    }
  }
  const handleStatusClose = () => {
    setShowStatus(false);
  }
  // const rows = [input];
  //Doubtfull need to check
  const columns = [
    { field: "Edition", headerName: "Edition", width: 100 },
    { field: "ModelYear", headerName: "Year", width: 100 },
    { field: "Make", headerName: "Make", width: 100 },
    { field: "Model", headerName: "Model", width: 100 },
    { field: "Trim", headerName: "Trim", width: 200 },
    { field: "Miles", headerName: "Miles", width: 80 },
    { field: "MSRP", headerName: "MSRP", width: 80 },
    { field: "MRM", headerName: "MRM", width: 80 },
    { field: "Term", headerName: "Term", width: 80 },
    { field: "RV", headerName: "Residual Value", width: 200 },
  ];
  // console.log("THIS IS TEST", rows);

  //import from CSV
  const handleOpenCSV = () => {
    setOpenCSV(true);
  };
  const buttonRef = useRef(null);
  const { CSVReader } = useCSVReader();

  const handleOnFileLoad = (data) => {
    //console.log(data);
  };

  const handleFileRemove = (data) => {
    //console.log(data);
  };
  const onErrorHandler = (err, file, inputElem, reason) => {
    //console.log(err);
  };
  function ObjectFieldTemplate(props) {
    return (
      <div>
        <Grid container spacing={2} sx={{ mt: 0.5 }}>
          {props.title}
          {props.description}
          {props.properties.map(element => <Grid item xs={6}><div className="property-wrapper">{element.content}</div></Grid>)}
        </Grid>
      </div>
    );
  }
  return (
    <div>
      <Grid container spacing={2} sx={{ p: 2 }} >
        <Grid item xs={4}>
          <Typography variant="h4" component="h1" >
            Residual Values
          </Typography>
        </Grid>
        <Grid item xs={8}>
          <Box
            sx={{ pb: 2 }}
            display="flex"
            justifyContent="flex-end"
            alignItems="flex-end"
          >
            <Button
              sx={{ m: 0.5 }}
              variant="contained"
              startIcon={<Add />}
              onClick={handleAddValue}
            >
              Add
            </Button>{" "}

            <Button sx={{ m: 0.5 }} variant="contained" startIcon={<Edit />}
              disabled={selectedRow == null}
              onClick={handleEditValue}>
              Edit
            </Button>{" "}
            <Button sx={{ m: 0.5 }} variant="contained" startIcon={<Delete />} 
              disabled={selectedRow == null}
              onClick={handleDeleteValue}>
              Delete
            </Button>
            <Button
              sx={{ m: 0.5 }}
              variant="contained"
              startIcon={<ImportExport />}
              onClick={handleOpenCSV}
            >
              Import
            </Button>
          </Box>
        </Grid>
      </Grid>
      <div className="data-grid">
        {rows && rows.length > 0 &&
          <DataGrid
            columns={columns}
            rows={rows}
            getRowId={(row) => row._id}
            disableMultipleRowSelection={true}
            onSelectionModelChange={(selection) => {
              if (selection && selection.length > 0) {
                const selected = rows.find(x => x._id == selection[0]);
                setSelectedRow(selected);
              }
              else {
                setSelectedRow(null);
              }
            }}
          />
        }
      </div>
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>{selectedRow ? "Edit" : "Add"} Residual Value</DialogTitle>
        <DialogContent>
          {loading && <CircularProgress />}
          <Form
            schema={schema}
            uiSchema={uiSchema}
            validator={validator}
            formData={selectedRow}
            onSubmit={(data) => { handleSave(data.formData) }}
            onError={log('errors')}
            className="editor-form"
          >
            <Button variant="contained" type="submit">Submit</Button>
            <Button variant="outlined" onClick={handleClose}>Cancel</Button>
          </Form>
        </DialogContent>
      </Dialog>
      <Snackbar
        open={showStatus}
        onClose={handleStatusClose}
        autoHideDuration={6000}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        message={status}
      >
      </Snackbar>
      <Dialog open={openCSV} onClose={handleCloseCSV}>
        <DialogTitle>Enter a value</DialogTitle>
        <DialogContent>
          <input type="file" onChange={handleFileUpload} />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseCSV} color="primary">
            Cancel
          </Button>
          <Button onClick={handleChangeCSV} color="primary">
            Save
          </Button>
        </DialogActions>
      </Dialog>
      {importCSVData && <TableForCSVImport dataCSV={dataFromCSV} />}
    </div>
  );
};

export default ResidualValues;
