import React, { useState } from "react";
import styled from "styled-components";
import { DataGrid } from "@mui/x-data-grid";

export default function TableFromCSVImports(props) {
  const [data, setData] = useState([]);
  let entries = [];
  let values = [];
  let keys = [];
  if (props.dataCSV && props.dataCSV[0] && props.dataCSV[0].length > 1) {
    // setData((old) => [...old, props.dataCSV[0]]);
    entries = Object.entries(props.dataCSV[0]);
    values = Object.values(props.dataCSV[0]);
    keys = Object.keys(Object.values(props.dataCSV[0])[0]);
  }
  console.log("Values", values);
  console.log("entries", entries);
  console.log("keys", keys);

  const columns = [
    { field: "Edition", headerName: "Edition", width: 100 },
    { field: "ModelYear", headerName: "Year", width: 100 },
    { field: "Make", headerName: "Make", width: 100 },
    { field: "Model", headerName: "Model", width: 100 },
    { field: "Trim", headerName: "Trim", width: 200 },
    { field: "Miles", headerName: "Miles", width: 80 },
    { field: "MSRP", headerName: "MSRP", width: 80 },
    { field: "MRM", headerName: "MRM", width: 80 },
    { field: "Term", headerName: "Term", width: 80 },
    { field: "RV", headerName: "RV", width: 80 },
  ];

  const rowLines = [...values];

  //css
  const Table = styled.table`
    border-collapse: collapse;
    width: 100%;
    margin-bottom: 20px;
  `;

  const Th = styled.th`
    background-color: #f2f2f2;
    color: #333;
    font-weight: bold;
    padding: 8px;
    text-align: left;
    border: 1px solid #ddd;
  `;

  const Td = styled.td`
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
  `;

  const Tr = styled.tr`
    &:nth-child(even) {
      background-color: #f2f2f2;
    }
  `;
  return (
    <>
      <Table>
        <thead>
          <Tr>
            {/* {props.dataCSV &&
            props.dataCSV[0] &&
            props.dataCSV[0].length > 1 &&
          props.dataCSV[0] */}

            {keys && keys.map((key) => <Th>{key}</Th>)}
          </Tr>
        </thead>
        <tbody>
          {values &&
            values.map((row, rowIndex) => (
              <Tr key={rowIndex}>
                {Object.values(row).map((item, index) => (
                  <Td key={index}>{item}</Td>
                ))}
              </Tr>
            ))}
        </tbody>
        <tbody>
          {values &&
            values.length > 1 &&
            values.map((row, rowIndex) => (
              <tr key={rowIndex}>
                {row &&
                  row.length > 1 &&
                  row.map((cell, cellIndex) => (
                    <td key={`${rowIndex}-${cellIndex}`}>
                      {Object.values(Object.cell(props.dataCSV[0])[cellIndex])}
                    </td>
                  ))}
              </tr>
            ))}
        </tbody>
      </Table>
      {/* <DataGrid columns={columns} rows={values} /> */}
    </>
  );
}

// export default TableFromCSVImports;

// // import React from "react";
// // import { useState } from "react";
// // import Papa from "papaparse";
// // // import Dialog from "@mui/material/Dialog";

// // import { Dialog } from "@mui/material";
// // import { DialogActions } from "@mui/material";
// // import { DialogContent } from "@mui/material";
// // import { DialogTitle } from "@mui/material";

// // function CSVImport() {
// //   const [value, setValue] = useState("");

// //   const [file, setFile] = useState(null);

// //   const handleFileUpload = (event) => {
// //     const uploadedFile = event.target.files[0];
// //     setFile(uploadedFile);
// //   };

// //   const handleCloseCSV = () => {
// //     setOpenCSV(false);
// //   };

// //   const handleSave = () => {
// //     console.log(value);
// //     handleCloseCSV();
// //   };

// //   const handleChangeCSV = (event) => {
// //     Papa.parse(file, {
// //       header: true,
// //       complete: (results) => {
// //         console.log("Data from Excel", results.data);
// //         // Do something with the parsed data
// //         setData(results.data);
// //       },
// //     });
// //     setOpenTable(true);
// //     handleCloseCSV();

// //     // setValue(event.target.value);
// //   };

// //   return (
// //     <div>
// //       <Dialog onClose={handleCloseCSV}>
// //         <DialogTitle>Enter a value</DialogTitle>
// //         <DialogContent>
// //           <input type="file" onChange={handleFileUpload} />
// //         </DialogContent>
// //         <DialogActions>
// //           <Button onClick={handleCloseCSV} color="primary">
// //             Cancel
// //           </Button>
// //           <Button onClick={handleChangeCSV} color="primary">
// //             Save
// //           </Button>
// //         </DialogActions>
// //       </Dialog>
// //     </div>
// //   );
// // }
// // export default CSVImport;
