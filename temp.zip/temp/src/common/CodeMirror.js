import React from 'react';
import Code from '@uiw/react-codemirror';
import { javascript } from '@codemirror/lang-javascript';
import python from '@uiw/react-codemirror/'

function CodeMirror() {
  const onChange = React.useCallback((value, viewUpdate) => {
    console.log('value:', value);
  }, []);
  return (
    <Code
      value="console.log('hello world!');"
      height="400px"
      extensions={[javascript({ jsx: true })]}
      onChange={onChange}
    />
  );
}
export default CodeMirror;