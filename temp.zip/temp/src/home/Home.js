import React from 'react';
import { Typography } from '@mui/material';

const Home = () => {
    return (
        <div>
            <Typography variant="h6" component="h1" sx={{ m: 0.5 }}>
                Welcome Payment Calculator Admin
            </Typography>
            <Typography variant="body1">

            </Typography>
        </div>
    );
};

export default Home;
