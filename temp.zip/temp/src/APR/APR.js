import React, { useState, useEffect } from "react";
import { Grid, Typography } from "@mui/material";
import {
  CircularProgress,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Box,
  TextField,
  Stack,
  Alert,
} from "@mui/material";
import Snackbar, { SnackbarOrigin } from "@mui/material/Snackbar";
import { Add, Edit, Delete, ImportExport } from "@mui/icons-material";
import { DataGrid } from "@mui/x-data-grid";
import { get, post, put, deleteRecord, handleApiError } from "../common/api";
import Form from "@rjsf/mui";
import validator from "@rjsf/validator-ajv8";

const APR = () => {
  const [rows, setRows] = useState([]);
  const [selectedRow, setSelectedRow] = useState(null);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState();
  const [showStatus, setShowStatus] = useState(false);

  const [schema, setSchema] = useState({});

  const uiSchema = {};

  let schemaWithModels = {
    title: "APR",
    description: "",
    type: "object",
    required: ["Term", "Credit Score"],
    properties: {
      Term: {
        type: "integer",
        title: "Term",
        default: "0",
      },
      "Credit Score": {
        type: "integer",
        title: "Credit Score",
      },
    },
  };

  //   setSchema(schemaWithModels);

  return (
    <div>
      <Grid container spacing={2} sx={{ p: 2 }}>
        <Grid item xs={4}>
          <Typography variant="h4" component="h1">
            APR
          </Typography>
        </Grid>
        <Grid item xs={8}>
          <Box
            sx={{ pb: 2 }}
            display="flex"
            justifyContent="flex-end"
            alignItems="flex-end"
          >
            <Button
              sx={{ m: 0.5 }}
              variant="contained"
              startIcon={<Add />}
              //   onClick={}
            >
              Add
            </Button>{" "}
            <Button
              sx={{ m: 0.5 }}
              variant="contained"
              startIcon={<Edit />}
              disabled={selectedRow == null}
              //   onClick={}
            >
              Edit
            </Button>{" "}
            <Button
              sx={{ m: 0.5 }}
              variant="contained"
              startIcon={<Delete />}
              disabled={selectedRow == null}
              //   onClick={}
            >
              Delete
            </Button>
            <Button
              sx={{ m: 0.5 }}
              variant="contained"
              startIcon={<ImportExport />}
              //   disabled={selectedRow == null}
              //   onClick={}
            >
              Import
            </Button>
          </Box>
        </Grid>
      </Grid>
    </div>
  );
};

export default APR;
