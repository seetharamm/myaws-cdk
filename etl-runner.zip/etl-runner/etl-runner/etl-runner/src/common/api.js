import axios from "axios";

// Set the default base URL for all API calls
axios.defaults.baseURL = process.env.REACT_APP_API_URL;

axios.defaults.headers.common["Authorization"] = `Bearer ${localStorage.getItem(
  "accessToken"
)}`;

const axiosInstance = axios.create({
  headers: {
    Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
    "Content-Type": `application/json`,
  },
});

export const get = async (endpoint) => {
  try {
    const response = await axiosInstance.get(endpoint);
    return response.data;
  } catch (error) {
    //handleApiError(error);
  }
};

export const post = async (endpoint, data) => {
  try {
    const response = await axiosInstance.post(endpoint, data);
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};
export const put = async (endpoint, data) => {
  try {
    const response = await axiosInstance.put(endpoint, data);
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

export const deleteRecord = async (endpoint) => {
  try {
    const response = await axiosInstance.delete(endpoint);
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};
// Create a function for handling API errors
const handleApiError = (error) => {
  if (error.response.status === 401) {
    // Handle unauthorized errors by redirecting to the login page or refreshing the access token
  } else {
    // Handle other errors by displaying an error message
  }
};
