import React from 'react';
import Code from '@uiw/react-codemirror';
import { javascript, } from '@codemirror/lang-javascript';
import python from '@uiw/react-codemirror'

function CodeMirror(props) {
  const {sendCode} = props;
  const onChange = React.useCallback((value, viewUpdate) => {
    console.log('value:', value);
    sendCode(value);
    
  }, []);
  return (
    <Code
      value=""
      height="450px"
      extensions={[javascript({ jsx: true })]}
      onChange={onChange}
    />
  );
}
export default CodeMirror;