import * as React from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import { Card, CardHeader, CardContent } from '@mui/material';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import { Paper } from '@mui/material';
import { styled } from '@mui/material/styles';
import CodeMirror from '../common/CodeMirror';
import Accordion, { AccordionSlots } from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Fade from '@mui/material/Fade';


const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));
export default function JobConfigForm(props) {
 const {sendConfig } = props;
 const [expanded, setExpanded] = React.useState(true);

 const handleExpansion = () => {
   setExpanded((prevExpanded) => !prevExpanded);
 };

  const handleForm = (evt) =>
  {
    if(evt.target.name == 'name')
    {
      sendConfig({'name':evt.target.value})
    }else if(evt.target.name == 'runTime')
    {
      sendConfig({'runTime':evt.target.value})
    }else if(evt.target.name == 'jobDesc')
    {
      sendConfig({'jobDesc':evt.target.value})
    }
    
  }
  return (
    <Grid container spacing={2}>
  <Grid item xs={4}>
    
    <Card >
        <CardHeader>
            <Typography>ddddddd</Typography>
            
        </CardHeader>
        <CardContent>
        <Box
        sx={{ height: '100%' }}
      component="form"
      
      noValidate
      autoComplete="off"
    >
      
      <TextField name="name" onChange={handleForm} fullWidth label="Name" variant="standard" />
      <TextField name="runTime" onChange={handleForm} fullWidth label="Runtime" variant="standard" />
      <TextField name="jobDesc" onChange={handleForm} fullWidth label="Job Desc" variant="standard" />
      <TextField name="options" onChange={handleForm} fullWidth label="Options" variant="standard" />
      <TextField name="jarLocation" onChange={handleForm} fullWidth label="Jar Location" variant="standard" />
      <TextField name="cores" onChange={handleForm} fullWidth label="Number Of Cores" variant="standard" />
    </Box>
        </CardContent>
    </Card>
    
  </Grid>
  <Grid item xs={8}>
    
    <Accordion
        expanded={expanded}
        onChange={handleExpansion}
        slotProps={{ transition: { timeout: 400 } }}
        sx={{
          '& .MuiAccordion-region': { height: expanded ? 'auto' : 0 },
          '& .MuiAccordionDetails-root': { display: expanded ? 'block' : 'none' },
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1-content"
          id="panel1-header"
        >
          Code Editor
        </AccordionSummary>
        <AccordionDetails>
        <CodeMirror/>
        </AccordionDetails>
      </Accordion>

    
  </Grid>
  
</Grid>
    
    
  );
}
