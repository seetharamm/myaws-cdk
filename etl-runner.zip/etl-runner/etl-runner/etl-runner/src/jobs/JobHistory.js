import React, { useState, useEffect } from "react";
import CloseIcon from "@mui/icons-material/Close"
import { DataGrid } from "@mui/x-data-grid";
import { Link } from "react-router-dom";
import { Box } from "@mui/material";
import { get, post, put, deleteRecord, handleApiError } from "../common/api";
import Chip, { ChipProps } from "@mui/material/Chip";
import { red, blue } from "@mui/material/colors";
const tabs = [
  {
    value:"0",
    label:"Code",
    active: true
  },
  {
    value:"1",
    label:"Job Config",
    active: false
  },
  {
    value:"2",
    label:"History",
    active: false
  },
  {
    value:"3",
    label:"Scheduled Info",
    active: false
  }
]
function getChipProps(params){
    const bb = <p style={{color:'red'}}>{params.value}</p>;
    const rr = <p style={{color:'blue'}}>{params.value}</p>;
  if (params.value > 10000) {
    return {
      
      label: bb,
      style: {
        borderColor: red[500]
      }
    };
  } else {
    return {
      
      label: rr,
      style: {
        borderColor: blue[500]
      }
    };
  }
}


const JobHistory = () => {
  let data ="print('uuuuuuuu')";
  const [rows, setRows] = useState([]);
  const [code, setCode] = useState();
  const [tabData, setTabData] = useState(tabs);
  const [selectedRow, setSelectedRow] = useState(true);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState();
  const [showStatus, setShowStatus] = useState(false);
  const [jobConfig, setJobConfig] = useState({name:"",runTime:"",jobDesc:""});
  
  const columns = [
    {
      field: "id",
      headerName: "App Id",

      width: 200,
      renderCell: (params) => 
      <Link to="/jobdetails">{params.row.id}</Link>,
    },
    {
        field: "name",
       
        headerName: "Job Name",
        flex:1,
        renderCell: (params) => 
        <Link to="/jobdetails">{params.row.name}</Link>,
      },
    {
      field: "lastUpdated",
     
      headerName: "Last Updation Date",
      flex:1
    },
    {
      field: "startTime",
      headerName: "Start Time",
      flex:1,
    },
    {
      field: "endTime",
      headerName: "End Time",
      flex:1
    },
    {
      field: "duration",
      headerName: "Duration",
      flex:1,
      renderCell: (params) => {
        return <Chip variant="outlined" size="small" {...getChipProps(params)} />;
      }
    },
    {
      field: "completed",
      headerName: "Completed",
      flex:1
    }
  ];
  const getScript = async (value) => {
    console.log(value);
    setCode(value);
    console.log(code);
    //const response = await get("http://localhost:8080/getJobConfigs/");
  }
  const getConfig = async (value) => {
    console.log(value);
    setCode(value);
    console.log(code);
    //const response = await get("http://localhost:8080/getJobConfigs/");
  }
  const handleTabsChange = async (value) => {
   for(let tab of tabs)
   {
    if(tab.value == value)
    {
      tab.active = true;
    }
    else
    {
      tab.active = false;
    }
   }
   setTabData(tabs);
    //setCode(value);
    //const response = await get("http://localhost:8080/getJobConfigs/");
  }


  const schema = {
    type: 'object',
    required: [
      "name",
      "creationDate"
    ],
    properties: {
      name: {
        type: 'string',
        title: 'Job Name'
      },
      creationDate: {
        type: 'string',
        title: 'Creation Date'
      },
      lastModifiedDate: {
        type: 'string',
        title: 'Last Modified Date'
      },
      jobDesc: {
        type: 'string',
        title: 'Job Description'
      },
      runTime: {
        type: 'string',
        title: 'Runtime'
      },
      code: {
        type: 'string',
        title: 'Code'
      }
    },
  };
  const uiSchema = {

  };


  const fetchData = async () => {
    debugger;
    const response = await get("http://localhost:8082/history");
    for(const elm of response)
    {
      Object.assign(elm,elm.attempts[0]);
      delete elm.attempts
    }
   console.log(response);
    if (response && response.length > 0) setRows(response);
  };
  useEffect(() => {
    fetchData();
  }, []);

  const handleClose = () => {
    setOpen(false);
  };
  const handleCloseIcon = () => {
    setOpen(false);
  };
  const handleCodeSave = async (data) => {
    setLoading(true);
  }
  const handleSave = async (data) => {
    setLoading(true);

    let response;

    if (data._id)
      response = await put("/getJobConfigs/" + data._id, { name: data.name });
    else
      response = await post("/getJobConfigs", { name: data.name });

    if (response) {
      setSelectedRow(null);
      fetchData();
      setOpen(false);
      setStatus("Model saved successfully.")
      setShowStatus(true);
    }
    else {
      setStatus("Error occured while adding the model.")
      setShowStatus(true);
    }
    setLoading(false);
  };
  const handleStatusClose = () => {
    setShowStatus(false);
  }
  const handleAddModel = () => {
    setSelectedRow(null);
    setOpen(true);
  }
  const handleEditModel = () => {
    setOpen(true);
  }
  const handleDeleteModel = async () => {
    setLoading(true);

    if (selectedRow._id) {
      const response = await deleteRecord("/getJobConfigs/" + selectedRow._id);
      setLoading(false);
      fetchData();
      setStatus("Model deleted successfully.")
      setShowStatus(true);
    }
  }
  const log = (type) => console.log.bind(console, type);
  const [finalClickInfo, setFinalClickInfo] = useState(null);

  const handleOnCellClick = (params) => {
    setFinalClickInfo(params);
  };
  return (
      
      <div className="data-grid">
        {rows && rows.length > 0 &&
         <Box >
          <DataGrid
            columns={columns}
            rows={rows}
            checkboxSelection
            hideScrollbar={true}
            getRowId={(row) => row.id}
            onCellClick={handleOnCellClick}
            disableMultipleRowSelection={true}
            onSelectionModelChange={(selection) => setSelectedRow(!selectedRow)}
            sx={{ height:530,width:'100%',display:'flex',overflowX: 'hiddden',
                "& .MuiDataGrid-columnHeaders": {
                    fontWeight: 400,
                    borderRadius: "var(--none, 0px)",
                    borderBottom: "1px solid var(--divider, rgba(0, 0, 0, 0.12))",
                    borderLeft: "var(--none, 0px) solid var(--divider, rgba(0, 0, 0, 0.12))",
                    borderRight: "var(--none, 0px) solid var(--divider, rgba(0, 0, 0, 0.12))",
                    borderTop: "var(--none, 0px) solid var(--divider, rgba(0, 0, 0, 0.12))",
                    background: "var(--primary-selected, rgba(33, 150, 243, 0.08))",
                    alignItems: 'space-between !important'
                },
                '--DataGrid-overlayHeight': '300px'
                }}
          />
          </Box>
        }
      </div>
  );
};

export default JobHistory;
