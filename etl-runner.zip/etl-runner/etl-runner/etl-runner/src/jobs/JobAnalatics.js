import { DataGrid, GridColDef, GridRenderCellParams } from "@mui/x-data-grid";
import WarningIcon from "@mui/icons-material/Warning";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import Chip, { ChipProps } from "@mui/material/Chip";
import { red, blue } from "@mui/material/colors";

function getChipProps(params){
    const ss = <p style={{color:'red'}}>This is a paragraph.</p>;
  if (params.value === "RED") {
    return {
      icon: <WarningIcon style={{ fill: red[500] }} />,
      label: params.value,
      style: {
        borderColor: red[500]
      }
    };
  } else {
    return {
      icon: <CheckCircleIcon style={{ fill: blue[500] }} />,
      label: ss,
      style: {
        borderColor: blue[500]
      }
    };
  }
}

const columns = [
  {
    field: "id",
    headerName: "id",
    flex: 1,
    minWidth: 50,
    description: "Row number",
    headerAlign: "left"
  },
  {
    field: "first_name",
    headerName: "First Name",
    flex: 1,
    minWidth: 100,
    description: "Candidate's first name",
    headerAlign: "left"
  },
  {
    field: "last_name",
    headerName: "Last Name",
    flex: 1,
    minWidth: 100,
    description: "Candidate's last name",
    headerAlign: "left"
  },
  {
    field: "status",
    headerName: "Status",
    flex: 1,
    minWidth: 100,
    description: "Status",
    headerAlign: "left",
    renderCell: (params) => {
      return <Chip variant="outlined" size="small" {...getChipProps(params)} />;
    }
  }
];

export default function JobAnalatics() {
  const rows = [
    { id: 1, first_name: "AAAAA", last_name: "AAAAA", status: "RED" },
    { id: 2, first_name: "BBBBB", last_name: "BBBBB", status: "GREEN" }
  ];

  return (
    <div style={{ height: 600, width: "100%" }}>
      <DataGrid
        rows={rows}
        columns={columns}
        pageSize={10}
        rowsPerPageOptions={[10]}
        disableSelectionOnClick
      />
    </div>
  );
}
