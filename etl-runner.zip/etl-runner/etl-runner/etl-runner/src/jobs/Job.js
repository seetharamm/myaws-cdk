import React, { useState, useEffect } from "react";
import { Grid, Typography } from "@mui/material";
import { Button, Dialog, DialogTitle, DialogContent, DialogActions, Box, TextField, Stack, Alert } from "@mui/material";
import Snackbar, { SnackbarOrigin } from '@mui/material/Snackbar';
import { Add, Edit, Delete, ImportExport } from "@mui/icons-material";
import CloseIcon from "@mui/icons-material/Close"
import { DataGrid } from "@mui/x-data-grid";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import MenuIcon from '@mui/icons-material/Menu';
import { Link } from "react-router-dom";
import { get, post, put, deleteRecord, handleApiError } from "../common/api";
import Form from '@rjsf/mui';
import validator from '@rjsf/validator-ajv8';
import ColorTabs from "../components/ColoredTabs";
const tabs = [
  {
    value:"0",
    label:"Code",
    active: true
  },
  {
    value:"1",
    label:"Job Config",
    active: false
  },
  {
    value:"2",
    label:"History",
    active: false
  },
  {
    value:"3",
    label:"Scheduled Info",
    active: false
  }
]



const Model = () => {
  let data ="print('uuuuuuuu')";
  const [rows, setRows] = useState([]);
  const [code, setCode] = useState();
  const [tabData, setTabData] = useState(tabs);
  const [selectedRow, setSelectedRow] = useState(true);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState();
  const [showStatus, setShowStatus] = useState(false);
  const [jobConfig, setJobConfig] = useState({name:"",runTime:"",jobDesc:""});
  const columns = [
    {
      field: "name",
      headerName: "Name",

      flex:1,
      renderCell: (params) => 
      <Link to="/jobdetails">{params.row.name}</Link>,
    },
    {
      field: "creationDate",
      flex:1,
      headerName: "Creation Date",
      
    },
    {
      field: "lastModifiedDate",
      headerName: "Last Modified Date",
      flex:1
    },
    {
      field: "jobDesc",
      headerName: "Job Description",
      flex:1
    },
    {
      field: "runTime",
      headerName: "RunTime",
      flex:1
    },
    {
      field: "code",
      headerName: "Code",
      flex:1
    }
  ];
  const getScript = async (value) => {
    console.log(value);
    setCode(value);
    console.log(code);
    //const response = await get("http://localhost:8080/getJobConfigs/");
  }
  const getConfig = async (value) => {
    console.log(value);
    setCode(value);
    console.log(code);
    //const response = await get("http://localhost:8080/getJobConfigs/");
  }
  const handleTabsChange = async (value) => {
   for(let tab of tabs)
   {
    if(tab.value == value)
    {
      tab.active = true;
    }
    else
    {
      tab.active = false;
    }
   }
   setTabData(tabs);
    //setCode(value);
    //const response = await get("http://localhost:8080/getJobConfigs/");
  }


  const schema = {
    type: 'object',
    required: [
      "name",
      "creationDate"
    ],
    properties: {
      name: {
        type: 'string',
        title: 'Job Name'
      },
      creationDate: {
        type: 'string',
        title: 'Creation Date'
      },
      lastModifiedDate: {
        type: 'string',
        title: 'Last Modified Date'
      },
      jobDesc: {
        type: 'string',
        title: 'Job Description'
      },
      runTime: {
        type: 'string',
        title: 'Runtime'
      },
      code: {
        type: 'string',
        title: 'Code'
      }
    },
  };
  const uiSchema = {

  };


  const fetchData = async () => {
    debugger;
    const response = await get("http://localhost:8082/getJobConfigs");
    if (response && response.length > 0) setRows(response);
  };
  useEffect(() => {
    fetchData();
  }, []);

  const handleClose = () => {
    setOpen(false);
  };
  const handleCloseIcon = () => {
    setOpen(false);
  };
  const handleCodeSave = async (data) => {
    setLoading(true);
  }
  const handleSave = async (data) => {
    setLoading(true);

    let response;

    if (data._id)
      response = await put("/getJobConfigs/" + data._id, { name: data.name });
    else
      response = await post("/getJobConfigs", { name: data.name });

    if (response) {
      setSelectedRow(null);
      fetchData();
      setOpen(false);
      setStatus("Model saved successfully.")
      setShowStatus(true);
    }
    else {
      setStatus("Error occured while adding the model.")
      setShowStatus(true);
    }
    setLoading(false);
  };
  const handleStatusClose = () => {
    setShowStatus(false);
  }
  const handleAddModel = () => {
    setSelectedRow(null);
    setOpen(true);
  }
  const handleEditModel = () => {
    setOpen(true);
  }
  const handleDeleteModel = async () => {
    setLoading(true);

    if (selectedRow._id) {
      const response = await deleteRecord("/getJobConfigs/" + selectedRow._id);
      setLoading(false);
      fetchData();
      setStatus("Model deleted successfully.")
      setShowStatus(true);
    }
  }
  const log = (type) => console.log.bind(console, type);
  const [finalClickInfo, setFinalClickInfo] = useState(null);

  const handleOnCellClick = (params) => {
    setFinalClickInfo(params);
  };
  return (
    <div>
      <Grid container spacing={2} sx={{ p: 2 }} >
        <Grid item xs={4}>
          <Typography sx={{mt:"2px"}} variant="h5" component="h1" >
            Job KPI
          </Typography>
        </Grid>
        <Grid item xs={8}>
          <Box
            sx={{ pb: 2 }}
            display="flex"
            justifyContent="flex-end"
            alignItems="flex-end"
          >
            <Button
              sx={{ m: 0.5 }}
              variant="contained"
              startIcon={<Add />}
              onClick={handleAddModel}
            >
            
            </Button>{" "}

            <Button sx={{ m: 0.5 }} variant="contained" startIcon={<Edit />}
              disabled={selectedRow}
              onClick={handleEditModel}>
              
            </Button>{" "}
            <Button sx={{ m: 0.5 }} variant="contained" startIcon={<Delete />}
              disabled={selectedRow}
              onClick={handleDeleteModel}>
              
            </Button>
          </Box>
        </Grid>
      </Grid>
      <div className="data-grid">
        {rows && rows.length > 0 &&
          <DataGrid
            columns={columns}
            rows={rows}
            checkboxSelection
            getRowId={(row) => row.id}
            onCellClick={handleOnCellClick}
            disableMultipleRowSelection={true}
            onSelectionModelChange={(selection) => setSelectedRow(!selectedRow)}
            sx={{ '--DataGrid-overlayHeight': '300px' ,  height:530,width:'100%'}}
          />
        }
      </div>
      <Dialog fullScreen sx={{ margin: '20px' }} open={open} onClose={() => setOpen(false)}>
        <DialogTitle sx={{ padding: 0 }}>
          <Grid container   >

            <Grid item xs={12} >
              <Box

                display="flex"
                justifyContent="flex-end"
                alignItems="flex-end"
              >
                <Button
                  sx={{ m: 0.5 }}
                  variant="contained"
                  startIcon={<Add />}
                  onClick={handleAddModel}
                >
                  Save
                </Button>{" "}

                <Button sx={{ m: 0.5 }} variant="contained" startIcon={<Edit />}

                  onClick={handleEditModel}>
                  Run
                </Button>{" "}
                <Button sx={{ m: 0.5 }} variant="contained" startIcon={<Delete />}
                  disabled={selectedRow == null}
                  onClick={handleDeleteModel}>
                  Delete
                </Button>{" "}
                <Button sx={{ m: 0.5}} variant="contained"
                  startIcon={<CloseIcon />}
                  onClick={handleCloseIcon}>
                  CLOSE
                </Button>

              </Box>
              
            </Grid>
          </Grid>
        </DialogTitle>
        <DialogContent >
          <ColorTabs getScript={getScript} 
                     getConfig={getConfig} 
                     tabData={tabData} 
                     handleTabChange={handleTabsChange}/>
        </DialogContent>
      </Dialog>
      <Snackbar
        open={showStatus}
        onClose={handleStatusClose}
        autoHideDuration={5000}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        message={status}
      >
      </Snackbar>
    </div>
  );
};

export default Model;
