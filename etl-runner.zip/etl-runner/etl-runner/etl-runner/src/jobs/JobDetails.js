import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import JobHistory from './JobHistory';
import JobConfigForm from './JobConfigForm';
import { Button } from '@mui/base';
import JobAnalatics from './JobAnalatics';
import { Grid } from '@mui/material';

export default () => (
    <Grid container spacing={2} sx={{ p: 2 }} >
        <Grid xs={12}>

        
  <Tabs  style={{marginLeft:'8px', marginTop:'2px'}}>
    <TabList sx={{marginLeft:'33px'}}>
      <Tab style={{backgroundColor:'#1976d2', color:'white'}}>Job Config</Tab>
      <Tab>Job History</Tab>
      <Tab>Job Impl</Tab>
      <Tab>Job Analytics</Tab>
      <Tab>Job SQL</Tab>
    </TabList>
    

    <TabPanel style={{height:'200px'}}>
    <JobConfigForm/>
    </TabPanel>
    <TabPanel>
    <JobHistory/>
      </TabPanel>
      <TabPanel>
    <JobAnalatics/>
      </TabPanel>
  </Tabs>
  </Grid>
  </Grid>
);