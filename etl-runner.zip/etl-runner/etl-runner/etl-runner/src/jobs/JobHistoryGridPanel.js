import React, { useState, useEffect } from "react";
import { Grid, Typography } from "@mui/material";
import { Button, Dialog, DialogTitle, DialogContent, DialogActions, Box, TextField, Stack, Alert } from "@mui/material";
import Snackbar, { SnackbarOrigin } from '@mui/material/Snackbar';
import { Add, Edit, Delete, ImportExport } from "@mui/icons-material";
import { DataGrid } from "@mui/x-data-grid";
import { get, post, put, deleteRecord, handleApiError } from "../common/api";
import Form from '@rjsf/mui';
import validator from '@rjsf/validator-ajv8';
import ColorTabs from "../components/ColoredTabs";



const JobHistoryGridPanel = () => {
  const [rows, setRows] = useState([]);
  const [selectedRow, setSelectedRow] = useState(null);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState();
  const [showStatus, setShowStatus] = useState(false);

  const columns = [
    { field: "name", 
      headerName: "Name", 
      width: 200,
      renderCell: (params) => {
        return params.value.toUpperCase();
      } },
      { 
        field: "creationDate", 
        headerName: "Creation Date", 
        width: 200
       },
       { 
        field: "lastModifiedDate", 
        headerName: "Last Modified Date", 
        width: 200
       },
       { 
        field: "jobDesc", 
        headerName: "Job Description", 
        width: 200
       },
       { 
        field: "runTime", 
        headerName: "RunTime", 
        width: 200
       }
  ];

  const schema = {
    type: 'object',
    required: [
      "name",
      "creationDate"
    ],
    properties: {
      name: {
        type: 'string',
        title: 'Job Name'
      },
      creationDate: {
        type: 'string',
        title: 'Creation Date'
      },
      lastModifiedDate: {
        type: 'string',
        title: 'Last Modified Date'
      },
      jobDesc: {
        type: 'string',
        title: 'Job Description'
      },
      runTime: {
        type: 'string',
        title: 'Runtime'
      },
    },
  };
  const uiSchema = {
    
  };


  const fetchData = async () => {
    debugger;
    const response = await get("http://localhost:8080/getJobConfigs");
    if (response && response.length > 0) setRows(response);
  };
  useEffect(() => {
    fetchData();
  }, []);

  const handleClose = () => {
    setOpen(false);
  };
  const handleSave = async (data) => {
    setLoading(true);

    let response;

    if (data._id)
      response = await put("/getJobConfigs/" + data._id, { name: data.name });
    else
      response = await post("/getJobConfigs", { name: data.name });

    if (response) {
      setSelectedRow(null);
      fetchData();
      setOpen(false);
      setStatus("Model saved successfully.")
      setShowStatus(true);
    }
    else {
      setStatus("Error occured while adding the model.")
      setShowStatus(true);
    }
    setLoading(false);
  };
  const handleStatusClose = () => {
    setShowStatus(false);
  }
  const handleAddModel = () => {
    setSelectedRow(null);
    setOpen(true);
  }
  const handleEditModel = () => {
    setOpen(true);
  }
  const handleDeleteModel = async () => {
    setLoading(true);

    if (selectedRow._id) {
      const response = await deleteRecord("/getJobConfigs/" + selectedRow._id);
      setLoading(false);
      fetchData();
      setStatus("Model deleted successfully.")
      setShowStatus(true);
    }
  }
  const log = (type) => console.log.bind(console, type);
  return (
    <div>
      <Grid container spacing={2} sx={{ p: 2 }} >
        <Grid item xs={4}>
          <Typography variant="h4" component="h1" >
            Job
          </Typography>
        </Grid>
        <Grid item xs={8}>
          <Box
            sx={{ pb: 2 }}
            display="flex"
            justifyContent="flex-end"
            alignItems="flex-end"
          >
            <Button
              sx={{ m: 0.5 }}
              variant="contained"
              startIcon={<Add />}
              onClick={handleAddModel}
            >
              Add
            </Button>{" "}

            <Button sx={{ m: 0.5 }} variant="contained" startIcon={<Edit />}
              disabled={selectedRow == null}
              onClick={handleEditModel}>
              Edit
            </Button>{" "}
            <Button sx={{ m: 0.5 }} variant="contained" startIcon={<Delete />}
              disabled={selectedRow == null}
              onClick={handleDeleteModel}>
              Delete
            </Button>
          </Box>
        </Grid>
      </Grid>
      <div className="data-grid">
        {rows && rows.length > 0 &&
          <DataGrid
            columns={columns}
            rows={rows}
            checkboxSelection
            getRowId={(row) => row.id}
            disableMultipleRowSelection={true}
            onSelectionModelChange={(selection) => {
              if (selection && selection.length > 0) {
                debugger;
                const selected = rows.find(x => x._id == selection[0]);
                setSelectedRow(selected);
              }
              else {
                setSelectedRow(null);
              }
            }}
          />
        }
      </div>
      
     
    </div>
  );
};

export default JobHistoryGridPanel;
