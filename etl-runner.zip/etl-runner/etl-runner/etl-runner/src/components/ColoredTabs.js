import * as React from 'react';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import { Typography } from '@mui/material';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import PhoneIcon from '@mui/icons-material/Code';
import FavoriteIcon from '@mui/icons-material/InfoSharp';
import PersonPinIcon from '@mui/icons-material/History';
import Scheduler from '@mui/icons-material/Schedule';
import CodeMirror from '../common/CodeMirror';
import JobConfigForm from '../jobs/JobConfigForm';

function TabPanel(props) {
    const { children, value, index,active, ...other } = props;
    const intValue = parseInt(value, 10);
    return (
      <div
        role="tabpanel"
        hidden={intValue !== index && active}
        id={`vertical-tabpanel-${index}`}
        aria-labelledby={`vertical-tab-${index}`}
        {...other}
      >
        {intValue === index && (
          <Box sx={{ p: 0.1 }}>
            <Typography>{children}</Typography>
          </Box>
        )}
      </div>
    );
  }
  
  
  function a11yProps(index) {
    return {
      id: `vertical-tab-${index}`,
      'aria-controls': `vertical-tabpanel-${index}`,
    };
  }
  
const CustTab = styled((props) => <Tab disableRipple {...props} />)(
    ({ theme }) => ({
      textTransform: 'none',
      minWidth: 0,
      [theme.breakpoints.up('sm')]: {
        minWidth: 0,
      },
      fontWeight: theme.typography.fontWeightRegular,
      marginRight: theme.spacing(1),
      color: 'rgba(0, 0, 0, 0.85)',
      fontFamily: [
        '-apple-system',
        'BlinkMacSystemFont',
        '"Segoe UI"',
        'Roboto',
        '"Helvetica Neue"',
        'Arial',
        'sans-serif',
        '"Apple Color Emoji"',
        '"Segoe UI Emoji"',
        '"Segoe UI Symbol"',
      ].join(','),
      '&:hover': {
        color: '#40a9ff',
        opacity: 1,
      },
      '&.Mui-selected': {
        color: '#1890ff',
        fontWeight: theme.typography.fontWeightMedium,
      },
      '&.Mui-focusVisible': {
        backgroundColor: '#d1eaff',
      },
    }),
  );
  
export default function ColorTabs(props) {
  const [value, setValue] = React.useState('0');
 
  const { getScript,getConfig, tabData, handleTabChange } = props;
  const handleChange = (event, newValue) => {
    handleTabChange(newValue);
    setValue(newValue);
  };
  const sendCode = (code) => {
    getScript(code);
  }
  const sendConfig = (config) => {
    getConfig(config);
  }
  
  return (
    <Box sx={{ width: '100%' }}>
      <Tabs
        value={value}
        onChange={handleChange}
        textColor="secondary"
        indicatorColor="secondary"
        aria-label="secondary tabs example"
      >{
        tabData.map(tab =>(
          <CustTab icon={<PhoneIcon/>} key={tab.value} 
             iconPosition="start" value={tab.value} label={tab.label} active={tab.active}></CustTab>
        ))
      }
       
      </Tabs>
      <TabPanel value={value} index={0}>
        <CodeMirror sendCode={sendCode}/>
      </TabPanel>
      <TabPanel value={value} index={1}>
        <JobConfigForm sendConfig={sendConfig}/>
      </TabPanel>
      <TabPanel value={value} index={2}>
        Item Three
      </TabPanel>
      <TabPanel value={value} index={3}>
        Item Four
      </TabPanel>
    </Box>
  );
}
