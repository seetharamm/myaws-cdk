import React from "react";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./common/header/Header";
import Job from "./jobs/Job";
import "./App.css";
import Workflow from "./Workflows/Workflow";
import ActiveJobs from "./jobs/ActiveJobs";
import JobDetails from "./jobs/JobDetails";
import JobHistory from "./jobs/JobHistory";



const theme = createTheme({
  palette: {
    mode: "light",
    primary: {
      main: "#8A6E33",
    },
    secondary: {
      main: "#e4dfd4",
    },
    background: {
      default: "#F1F1F1",
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <Router>
        <div>
          <Header />
          <Routes>
            <Route path="/" exact element={<Job />} />
            <Route path="/job" element={<Job />} />
            <Route path="/jobhistory" element={<JobHistory />} />
            <Route path="/jobdetails" element={<JobDetails />} />
            <Route path="/workflow" element={<Workflow />} />
            <Route path="/activeJobs" element={<ActiveJobs />} />
          </Routes>
        </div>
      </Router>
    </ThemeProvider>
  );
}

export default App;
