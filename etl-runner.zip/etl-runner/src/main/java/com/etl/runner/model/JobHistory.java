package com.etl.runner.model;

import java.util.Date;
import java.util.List;


public class JobHistory {

	private int id;
	private String name;
	private long duration;
	private Date startTime;
	private Date endTime;
	private Date lastUpdated;
	private Boolean completed;
	private String sparkUser;
	private List<Object> attempts;


	public List<Object> getAttempts() {
		return attempts;
	}

	public void setAttempts(List<Object> attempts) {
		this.attempts = attempts;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getDuration() {
		return duration;
	}

	public void setDuration(long duration) {
		this.duration = duration;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public Boolean getCompleted() {
		return completed;
	}

	public void setCompleted(Boolean completed) {
		this.completed = completed;
	}

	public String getSparkUser() {
		return sparkUser;
	}

	public void setSparkUser(String sparkUser) {
		this.sparkUser = sparkUser;
	}

}
