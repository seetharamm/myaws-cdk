package com.etl.runner.scheduleconfig;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@Configuration

public class SchedulerConfig {
	
	
	/*@Scheduled(fixedRate = 30000)
	public void periodicalRunningSparkJob() {
	    System.out.println("Spark job periodically execution");
	    //startApacheSparkApplication();
	}
*/
}
