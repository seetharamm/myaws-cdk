package com.etl.runner.controller;

import java.util.*;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.etl.runner.common.FileUtility;
import com.etl.runner.entity.Job;
import com.etl.runner.jpa.JobRepository;

import lombok.extern.slf4j.Slf4j;


@RestController
@CrossOrigin(origins = "*")
@Slf4j
public class JobConfigurationController {
	
	@Autowired
	JobRepository jobConfigRepository;
	
	@PostMapping(value="/createSparkJob")
	public ResponseEntity<Object> createJob(@RequestBody Job job){
		Job jobConfig;
		try {
			 jobConfig = jobConfigRepository.save(new Job(job.getName(),
					 job.getCode(),
					 new Date(), 
					 new Date(),
					 job.getJobDesc(),
					 job.getRunTime(), null));
			 FileUtility fl = new FileUtility();
			 fl.persistJob(jobConfig.getName(),jobConfig.getCode());
			
		}catch(Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<>(jobConfig, HttpStatus.CREATED);
	}
	@RequestMapping(value="/getJobConfig", method=RequestMethod.GET)
	public ResponseEntity<Object> getJobConfig(@PathVariable("id") long id)
	{
		Optional<Job> jobConfig = jobConfigRepository.findById(id);
		
		if(jobConfig.isPresent())
			return new ResponseEntity<>(jobConfig.get(),HttpStatus.OK);
		else
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		
		
	}
	@RequestMapping(value="/getJobConfigs", method=RequestMethod.GET)
	public ResponseEntity<List<Job>> getAllJobConfig()
	{
		List<Job> jobConfigs = new ArrayList<Job>();
		try {
			jobConfigRepository.findAll().forEach(jobConfigs::add);
			
		}catch(Exception e) {
			
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
		if(jobConfigs.size() > 1)
			return new ResponseEntity<>(jobConfigs,HttpStatus.OK);
		else
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		
		
	}

}
