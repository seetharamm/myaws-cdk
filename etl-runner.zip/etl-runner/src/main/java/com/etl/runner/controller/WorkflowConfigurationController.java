package com.etl.runner.controller;

import java.util.*;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.etl.runner.common.FileUtility;
import com.etl.runner.entity.Job;
import com.etl.runner.entity.Workflow;
import com.etl.runner.jpa.JobRepository;
import com.etl.runner.jpa.WorkflowRepository;
import com.etl.runner.service.JobRunnerService;

import lombok.extern.slf4j.Slf4j;


@RestController
@CrossOrigin(origins = "*")
@Slf4j
public class WorkflowConfigurationController {
	
	@Autowired
	WorkflowRepository workflowRepository;
	
	@Autowired
	JobRunnerService jobRunnerService;
	
	@PostMapping(value="/saveWorkflow")
	public ResponseEntity<Object> saveWorkflow(@RequestBody Workflow wf){
		Workflow saveWorkflow;
		try {
			saveWorkflow = workflowRepository.save(new Workflow(wf.getName(),
					 wf.getCreatedBy(),new Date(), wf.getModifiedBy(),new Date()));
			 
			
		}catch(Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<>(saveWorkflow, HttpStatus.CREATED);
	}
	@RequestMapping(value="/getWorkflowConfig", method=RequestMethod.GET)
	public ResponseEntity<Object> getWorkflowConfig(@PathVariable("id") long id)
	{
		Optional<Workflow> workflowConfig = workflowRepository.findById(id);
		
		if(workflowConfig.isPresent())
			return new ResponseEntity<>(workflowConfig.get(),HttpStatus.OK);
		else
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		
		
	}
	@RequestMapping(value="/getWorkflowConfigs", method=RequestMethod.GET)
	public ResponseEntity<List<Workflow>> getAllWfConfig()
	{
		List<Workflow> workflowConfigs = new ArrayList<Workflow>();
		try {
			workflowRepository.findAll().forEach(workflowConfigs::add);
			
		}catch(Exception e) {
			
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
		if(workflowConfigs.size() > 1)
			return new ResponseEntity<>(workflowConfigs,HttpStatus.OK);
		else
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		
		
	}
	@GetMapping(value="/initiateWorkflow")
	public ResponseEntity<String> initiateWorkflow()
	{
		String ss;
		List<Workflow> workflowConfigs = new ArrayList<Workflow>();
		try {
			 jobRunnerService.executeAsync();
			
		}catch(Exception e) {
			
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
		if(workflowConfigs.size() > 1)
			return new ResponseEntity<>(HttpStatus.OK);
		else
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		
		
	}

}
