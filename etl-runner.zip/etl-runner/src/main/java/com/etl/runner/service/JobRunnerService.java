package com.etl.runner.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.etl.runner.spark.WorkflowRunner;

@Service
public class JobRunnerService {

	@Autowired
	WorkflowRunner workflowRunner;

	public void executeAsync() {
		List<CompletableFuture<String>> futureList = new ArrayList<>();
		List<String> jobNames = new ArrayList<>();
		jobNames.add("basic.py");
		jobNames.add("basic1.py");
		jobNames.add("basic2.py");

		for (String jobName : jobNames) {
			CompletableFuture<String> future = CompletableFuture
					.supplyAsync(() -> workflowRunner.executeAsync(jobName))
					.exceptionally(ex -> {
						System.out.printf("Api 4 threw  exception msg-{} ", ex.getMessage());
						return "Fallback Response----" + ex.getMessage();
					});
			;
			futureList.add(future);
		}
		 CompletableFuture<Void> allFuturesResult =
				    CompletableFuture.allOf(futureList.toArray(new CompletableFuture[futureList.size()]));
		 allFuturesResult.join();
		

		// Wait for all CompletableFuture to complete and collect the results
		List<Integer> resultList = new ArrayList<>();
		for (Integer i = 1; i <= jobNames.size(); i++) {
			try {
				String result = futureList.get(i - 1).get();
				System.out.println("result----------------------------");
				System.out.println(result);
			} catch (InterruptedException | ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// log.info("API RESPONSE FOR PARAM {} is {}", i, result);
		}
		
	}
	public void executeSync() {
		List<CompletableFuture<String>> futureList = new ArrayList<>();
		List<String> jobNames = new ArrayList<>();
		jobNames.add("basic.py");
		jobNames.add("basic1.py");
		jobNames.add("basic2.py");

		for (String jobName : jobNames) {
			CompletableFuture<String> future = CompletableFuture
					.supplyAsync(() -> workflowRunner.executeAsync(jobName))
					.exceptionally(ex -> {
						
						return "Fallback Response----" + ex.getMessage();
					});
			;
			futureList.add(future);
		}
		 CompletableFuture<Void> allFuturesResult =
				    CompletableFuture.allOf(futureList.toArray(new CompletableFuture[futureList.size()]));
		 allFuturesResult.join();
		

		// Wait for all CompletableFuture to complete and collect the results
		List<Integer> resultList = new ArrayList<>();
		for (Integer i = 1; i <= jobNames.size(); i++) {
			try {
				String result = futureList.get(i - 1).get();
				
			} catch (InterruptedException | ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// log.info("API RESPONSE FOR PARAM {} is {}", i, result);
		}
		
	}
	public void execute1() {
		List<CompletableFuture<String>> futureList = new ArrayList<>();
		List<String> jobNames = new ArrayList<>();
		jobNames.add("basic.py");
		jobNames.add("basic1.py");
		jobNames.add("basic2.py");
		CompletableFuture<String> future1 = CompletableFuture
				.supplyAsync(() -> workflowRunner.executeAsync("basic2.py"));
		CompletableFuture<String> future2 = CompletableFuture
				.supplyAsync(() -> workflowRunner.executeAsync("basic1.py"));
		CompletableFuture<String> future3 = CompletableFuture
				.supplyAsync(() -> workflowRunner.executeAsync("basic.py"));
	   

	    CompletableFuture<Void> combinedFuture = CompletableFuture.allOf(future1, future2,future3);

	    // Wait for both API calls to complete
	    combinedFuture.join();
	    String api1Result;
	    String api2Result ;
	    String api3Result ;
	    // Get the results from the CompletableFutures
	    try {
			 api1Result = future1.get();
			 api2Result = future2.get();
		     api3Result = future3.get();
		     System.out.println(api1Result+"---"+api2Result+"-----"+api1Result);
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
		
		

	}
}
