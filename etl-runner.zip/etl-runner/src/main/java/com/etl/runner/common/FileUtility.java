package com.etl.runner.common;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileUtility {
	
	


public boolean persistJob(String jobName, String code)
{
	Path filePath = Paths.get("src/main/resources/jobs"+"/"+jobName+".py");
	Boolean bool = Files.exists(filePath);
	if(!bool)
	{
		try {
			Path file = Files.createFile(filePath);
			FileWriter myWriter = new FileWriter(file.toString());
			myWriter.write(code);
			myWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	
	return false;
	
}
}
