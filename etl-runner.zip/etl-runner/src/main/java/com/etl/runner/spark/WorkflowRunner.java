package com.etl.runner.spark;

import java.io.BufferedReader;
import java.io.InputStreamReader;



import lombok.extern.slf4j.Slf4j;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class WorkflowRunner {

	public String executeAsync(String jobName)
	{
		try {
			
    		
    			ProcessBuilder builder = new ProcessBuilder(
        	            "cmd.exe", "/c", "spark-submit src/main/resources/jobs"+"/"+jobName);
        	        builder.redirectErrorStream(true);
        	        Process p = builder.start();
        	        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        	        String line;
        	        while (true) {
        	            line = r.readLine();
        	            if (line == null) { break; }
        	            System.out.println(line);
        	            
        	        }
    		
    		
    	}catch(Exception e)
    	{
    		e.printStackTrace();
    		return e.toString();
    	}
		return jobName;
    	 
	}
}
