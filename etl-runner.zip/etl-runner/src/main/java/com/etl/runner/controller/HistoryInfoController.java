package com.etl.runner.controller;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.etl.runner.model.JobHistory;
import com.etl.runner.ws.RestServices;

import java.util.List;

@CrossOrigin("*")
@RestController
public class HistoryInfoController {

	@Autowired
	RestServices restServices;

	@GetMapping(value = "/history")
	public List<JobHistory> getHistory() {
		List<JobHistory> jobHist = restServices.getHistory();
		for(Object obj: jobHist)
		{
		//System.out.println(obj);
		System.out.println(obj);
		}

		return jobHist;

	}

}
