package com.etl.runner.controller;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class TestContoller {
	
	@GetMapping("/test")
	public String executeAsync(String jobName)
	{
		try {
			
    		
    			ProcessBuilder builder = new ProcessBuilder(
        	            "cmd.exe", "/c", "spark-submit src/main/resources/jobs"+"/"+jobName);
        	        builder.redirectErrorStream(true);
        	        Process p = builder.start();
        	        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        	        String line;
        	        while (true) {
        	            line = r.readLine();
        	            if (line == null) { break; }
        	            System.out.println(line);
        	            
        	        }
    		
    		
    	}catch(Exception e)
    	{
    		e.printStackTrace();
    		return e.toString();
    	}
		return jobName;
    	 
	}

}
