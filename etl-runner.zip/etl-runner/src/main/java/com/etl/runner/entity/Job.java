package com.etl.runner.entity;

import java.util.Date;

import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name="JobConfig")
public class Job {

	
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	private long id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="code")
	private String code;
	
	@Column(name="creationDate")
	private Date creationDate;
	
	
	
	
	
	@Column(name="lastModifiedDate")
	private Date lastModifiedDate;
	
	@Column(name="jobDesc")
	private String jobDesc;
	
	@Column(name="runTime")
	private String runTime;
	
	
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getJobDesc() {
		return jobDesc;
	}
	public void setJobDesc(String jobDesc) {
		this.jobDesc = jobDesc;
	}
	public String getRunTime() {
		return runTime;
	}
	public void setRunTime(String runTime) {
		this.runTime = runTime;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public Job(String name, String code, Date creationDate, Date lastModifiedDate, String jobDesc, String runTime) {
		this.name = name;
		this.code = code;
		this.creationDate = creationDate;
		this.lastModifiedDate = lastModifiedDate;
		this.jobDesc = jobDesc;
		this.runTime = runTime;
		
	}
	public Job() {
		
	}
	
}
