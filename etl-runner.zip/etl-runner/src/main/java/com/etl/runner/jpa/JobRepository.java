package com.etl.runner.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.etl.runner.entity.Job;

public interface JobRepository extends JpaRepository<Job, Long>{

}
