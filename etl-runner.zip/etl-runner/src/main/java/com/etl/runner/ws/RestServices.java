package com.etl.runner.ws;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

import com.etl.runner.model.JobHistory;

@Service
public class RestServices {
	
	
	@Autowired
	   RestTemplate restTemplate;

	   @SuppressWarnings("unchecked")
	
	   public List<JobHistory> getHistory() {
	      HttpHeaders headers = new HttpHeaders();
	      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	      HttpEntity<String> entity = new HttpEntity<String>(headers);
	      
	      return (List<JobHistory>) restTemplate.exchange(
	         "http://localhost:18080/api/v1/applications", HttpMethod.GET, entity, Object.class).getBody();
	   }

}
