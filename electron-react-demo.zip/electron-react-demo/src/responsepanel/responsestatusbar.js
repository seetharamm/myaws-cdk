import { Box } from '@mui/material';

function ResponseStatusBar() {
    return (  

    <Box sx={{width:'100%', height:'34px',marginTop:"1px"}}>

    </Box>
    );
}

export default ResponseStatusBar;