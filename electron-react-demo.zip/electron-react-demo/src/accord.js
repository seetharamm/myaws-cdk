import * as React from 'react';
import { styled } from '@mui/material/styles';
import ArrowForwardIosSharpIcon from '@mui/icons-material/ArrowForwardIosSharp';
import MuiAccordion, { AccordionProps } from '@mui/material/Accordion';
import MuiAccordionSummary, {
    AccordionSummaryProps,
} from '@mui/material/AccordionSummary';
import MuiAccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import { Box } from '@mui/material';

const Accordion = styled((props) => (
    <MuiAccordion disableGutters elevation={0} square {...props} />
))(({ theme }) => ({
    border: `1px solid ${theme.palette.divider}`,
    '&:not(:last-child)': {
        borderBottom: 0,
    },
    '&:before': {
        display: 'none',
    },
}));

const AccordionSummary = styled((props) => (
    <MuiAccordionSummary
        expandIcon={<ArrowForwardIosSharpIcon sx={{ fontSize: '0.9rem' }} />}
        {...props}
    />
))(({ theme }) => ({
    backgroundColor:
        theme.palette.mode === 'dark'
            ? 'rgba(255, 255, 255, .05)'
            : 'rgba(0, 0, 0, .03)',
    flexDirection: 'row-reverse',
    '& .MuiAccordionSummary-expandIconWrapper.Mui-expanded': {
        transform: 'rotate(90deg)',
    },
    '& .MuiAccordionSummary-content': {
        marginLeft: theme.spacing(1),
    },
}));

const AccordionDetails = styled(MuiAccordionDetails)(({ theme }) => ({
    padding: theme.spacing(2),
    borderTop: '1px solid rgba(0, 0, 0, .125)',
}));
const RenderRequest = function () {

    return (

        <div style={{
            width: '100%',
            marginBottom: "9px",
            marginTop: "9px",
            marginLeft: "9px"
        }}>
            <Box component="div" sx={{ display: 'inline', fontSize: "12px", color: "blue", p: 1 }}>GET</Box>
            <Box component="div" sx={{ display: 'inline' }}>getRequest</Box>
        </div>

    )
}

export default function CustomizedAccordions() {

    const data =
        [{
            "_id": "req_082e313c18be47b1a7757509133b5ab4",
            "type": "Request",
            "parentId": "wrk_816a6e6fd41b4b0489d9449521990861",
            "modified": 1681909225849,
            "created": 1681822922202,
            "url": "https://jsonplaceholder.typicode.com/todos/",
            "name": "New Request",
            "description": "",
            "method": "PUT",
            "body": {},
            "parameters": [],
            "headers": [],
            "authentication": {}
        },
        {
            "_id": "req_082e313c18be47b1a7757509133b5ab3",
            "type": "folder",
            "parentId": "wrk_816a6e6fd41b4b0489d9449521990861",
            "modified": 1681909225849,
            "created": 1681822922202,
            "url": "https://jsonplaceholder.typicode.com/todos/",
            "name": "New Request",
            "description": "",
            "method": "PUT",
            "body": {},
            "parameters": [],
            "headers": [],
            "authentication": {},
            "children": [

                {
                    "_id": "req_082e313c18be47b1a7757509133b5ab4",
                    "type": "Request",
                    "parentId": "wrk_816a6e6fd41b4b0489d9449521990861",
                    "modified": 1681909225849,
                    "created": 1681822922202,
                    "url": "https://jsonplaceholder.typicode.com/todos/",
                    "name": "updateRequest",
                    "description": "",
                    "method": "PUT",
                    "body": {},
                    "parameters": [],
                    "headers": [],
                    "authentication": {}
                },
                {
                    "_id": "req_082e313c18be47b1a7757509133b5ab4",
                    "type": "Request",
                    "parentId": "wrk_816a6e6fd41b4b0489d9449521990861",
                    "modified": 1681909225849,
                    "created": 1681822922202,
                    "url": "https://jsonplaceholder.typicode.com/todos/",
                    "name": "getRequest",
                    "description": "",
                    "method": "PUT",
                    "body": {},
                    "parameters": [],
                    "headers": [],
                    "authentication": {}
                }

            ]
        }];
    const [expanded, setExpanded] = React.useState('panel1');

    const handleChange =
        (panel) => (event, newExpanded) => {
            setExpanded(newExpanded ? panel : false);
        };

    return (
        <div>
            <div style={{
                width: '100%',
                marginBottom: "9px",
                marginTop: "9px",
                marginLeft: "9px"
            }}>
                <Box component="div" sx={{ display: 'inline', fontSize: "12px", color: "blue", p: 1 }}>GET</Box>
                <Box component="div" sx={{ display: 'inline' }}>getRequest</Box>
            </div>
            <Accordion onChange={handleChange('panel1')}>
                <AccordionSummary aria-controls="panel1d-content" id="panel1d-header">
                    <Typography>panel1d-header</Typography>
                </AccordionSummary>
                <AccordionDetails>
                    <Accordion onChange={handleChange('panel111')}>
                        <AccordionSummary aria-controls="panel11d-content" id="panel11d-header11">
                            <Typography>panel11d-header1</Typography>
                        </AccordionSummary>
                        <AccordionDetails>
                            <div style={{ width: '100%', marginBottom: "9px" }}>
                                <Box component="div" sx={{ display: 'inline', fontSize: "12px", color: "blue", p: 1 }}>GET</Box>
                                <Box component="div" sx={{ display: 'inline' }}>getRequest</Box>
                            </div>
                            <div style={{ width: '100%', marginBottom: "9px" }}>
                                <Box component="div" sx={{ display: 'inline', fontSize: "12px", color: "blue", p: 1 }}>PUT</Box>
                                <Box component="div" sx={{ display: 'inline' }}>getRequest</Box>
                            </div>
                        </AccordionDetails>
                    </Accordion>
                    <Accordion onChange={handleChange('panel112')}>
                        <AccordionSummary aria-controls="panel12d-content" id="panel12d-header12">
                            <Typography>panel12d-header12</Typography>
                        </AccordionSummary>
                        <AccordionDetails>
                            <Typography>
                                putRequest
                            </Typography>
                        </AccordionDetails>
                    </Accordion>
                    <Accordion onChange={handleChange('panel113')}>
                        <AccordionSummary aria-controls="panel113-content" id="panel13d-header13">
                            <Typography>panel13d-header13</Typography>
                        </AccordionSummary>
                        <AccordionDetails>
                            <Typography>
                                GetRequest
                            </Typography>
                        </AccordionDetails>
                    </Accordion>
                </AccordionDetails>
            </Accordion>
            <Accordion onChange={handleChange('panel2')}>
                <AccordionSummary aria-controls="panel2d-content" id="panel2d-header">
                    <Typography>Collapsible1 </Typography>
                </AccordionSummary>
                <AccordionDetails>
                    <Typography>
                        DeleteRequest
                    </Typography>
                </AccordionDetails>
            </Accordion>
            <Accordion onChange={handleChange('panel3')}>
                <AccordionSummary aria-controls="panel3d-content" id="panel3d-header">
                    <Typography>Collapsible2</Typography>
                </AccordionSummary>

            </Accordion>
        </div>
    );
}
