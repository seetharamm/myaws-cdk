const { app, BrowserWindow, ipcMain, dialog } = require('electron/main')
const path = require('path')
const  fs = require('fs');
var nodeConsole = require('console');
var myConsole = new nodeConsole.Console(process.stdout, process.stderr);
myConsole.log('Hello World!');

async function handleFileOpen () {
  const { canceled, filePaths } = await dialog.showOpenDialog()
  if (!canceled) {
    return filePaths[0]
  }
}

ipcMain.handle('readdirSync', (event, pt) => 
myConsole.log("path is",pt),
fs.readdirSync(pt, { encoding: 'utf-8', withFileTypes: true })
)
ipcMain.handle('isDirectory', (pt) => 
fs.lstatSync(pt).isDirectory()
)

function createWindow () {
  const mainWindow = new BrowserWindow({
    webPreferences: {
        contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: true
    }
  })
  mainWindow.loadURL('http://localhost:3000/')
}

app.whenReady().then(() => {
  ipcMain.handle('dialog:openFile', handleFileOpen)
  createWindow()
  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit()
})