const { contextBridge } =  require('electron/renderer');
//const  electronAPI  = require('@electron-toolkit/preload');
const  fs = require('fs');
const { ipcRenderer } = require('electron')


contextBridge.exposeInMainWorld('electron', {
  openFile: () => ipcRenderer.invoke('dialog:openFile')
})
contextBridge.exposeInMainWorld('dir', {
  isDir: (path) => ipcRenderer.invoke('isDirectory')
})
contextBridge.exposeInMainWorld('rd', {
  rd: (path) => ipcRenderer.invoke('readdirSync', path)
})
